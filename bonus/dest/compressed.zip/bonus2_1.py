password = input("Enter your password")

while password != "Pass@123":
    print("Your password mismatches")
    password = input("Enter your password")

print("Password is correct")