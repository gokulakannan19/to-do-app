title = input("Enter the title: ")

length = len(title)

print(f"The length of the title is {length}")